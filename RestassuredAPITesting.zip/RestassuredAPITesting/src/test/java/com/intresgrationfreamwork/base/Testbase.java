package com.intresgrationfreamwork.base;


import org.apache.log4j.Level;
import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;
import org.testng.annotations.BeforeClass;

import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class Testbase {
	
	public static RequestSpecification httpRequest;
	public static Response response;
	public String empID="1";// hard coded value - input for get details of single emp & update emp

	
	
	public Logger logger;
	
	@BeforeClass
	public void setup() {
		logger= Logger.getLogger("TC001_Get_All_Emps");//added logger
		PropertyConfigurator.configure("/media/rohit/E/Perfomance/Eclipsejmeter/RestassuredAPITesting/test-output/Log4j.properties");//added logger
		logger.setLevel(Level.DEBUG);
	}
}
