package com.intresgrationfreamwork.testCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.intresgrationfreamwork.base.Testbase;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.response.Response;

public class TC001_Get_All_Emps extends Testbase {
	
	@BeforeClass
	void getAllEmpployees() throws Exception 
	{
	logger.info("*****************Started TC001_Get_All_Emp*******************");
	
	RestAssured.baseURI ="http://dummy.restapiexample.com/api/v1";
	httpRequest= RestAssured.given();
    response=httpRequest.request(Method.GET,"/employees");
    Thread.sleep(3);
	}
	
	@Test(enabled=true)
	void checkResponseBody()
	{
	  logger.info("*****************Checking the Response body*******************");
	  
	  String responseBody= response.asString();
	  logger.info("Response Body==>"+responseBody);
	  AssertJUnit.assertTrue(responseBody!=null);
	}
	/*@Test(enabled=true)
	void checkResponseBody2()
	{
		  logger.info("*****************Checking the Response body*******************");
		  
		  String responseBody= response.getBody().asString();
		  logger.info("Response Body==>"+responseBody);
		  Assert.assertEquals(responseBody.contains(id), true);
		}*/
	@Test(enabled=true)
	void checkStatusCode()
	{
	  logger.info("*****************Checking the  status Code *******************");
	  
	  int statusCode= response.getStatusCode();//getting the status code
	  logger.info("Status code is ==>"+ statusCode);
	  AssertJUnit.assertEquals(statusCode, 200);
	}
	@Test(enabled=true)
	void checkResponseTime()
	{
	  logger.info("*****************Checking the  Response Time *******************");
	  
	  long responseTime= response.getTime();//getting the responseTime
	  logger.info("Response Time  is ==>"+ responseTime);
	  
	  if (responseTime>2000) 
		  logger.info("Response time greater than  2000");
	  
	  AssertJUnit.assertTrue(responseTime<2000);
	  
	} 
	  @Test(enabled=true)
		void checkStatusLine()
		{
		  logger.info("*****************Checking the  Status line *******************");
		  
		  String  statusLine= response.getStatusLine();
		  logger.info("Status line   is ==>"+ statusLine);
		  AssertJUnit.assertEquals(statusLine, "HTTP/1.1 200 OK");
	    }
	  @Test(enabled=true)
		void checkcontentType()
		{
		  logger.info("*****************Checking the  Content type *******************");
		  
		  String  contentType= response.header("content-type");
		  logger.info("ContentType is  ==>"+ contentType);
		  AssertJUnit.assertEquals(contentType, "application/json;charset=utf-8");
	    }
	  @Test(enabled=true)
		void checkServerType()
		{
		  logger.info("*****************Checking the  Server type *******************");
		  
		  String  serverType= response.header("Server");
		  logger.info("server Type is  ==>"+ serverType);
		  AssertJUnit.assertEquals(serverType, "nginx/1.16.0");
	    }

	  @Test(enabled=true)
		void checkContentEncoding()
		{
		  logger.info("*****************Checking Content Encoding *******************");
		  
		  String  contentEncoding= response.header("Content-Encoding");
		  logger.info("Content Encoding  is  ==>"+ contentEncoding);
		  AssertJUnit.assertEquals(contentEncoding, "gzip");
	    }
	  @Test(enabled=true)
		void checkContentLength()
		{
		  logger.info("*****************Checking Content Length *******************");
		  
		  String  contentLenght= response.header("Content-Length");
		  logger.info("server Type is  ==>"+ contentLenght);
		  
		  if (Integer.parseInt(contentLenght)<100) 
			  logger.warn("Content length is less than 100");
			  
		  AssertJUnit.assertTrue(Integer.parseInt(contentLenght)>100);
	    }
	  @Test(enabled=true)
		void checkCookies()
		{
		  logger.info("*****************Checking Cookies *******************");
		  
		  String  cookie= response.getCookie("PHPSESSID");
	   }
	  @AfterMethod
	  
	  void tearDown()
	  {
		  logger.info("*****************Finised TC001_GET_All_Employees *******************");
	  }
}
