package com.intresgrationfreamwork.testCases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.json.simple.JSONObject;
import org.testng.Assert;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.intresgrationfreamwork.base.Testbase;
import com.intresgrationfreamwork.utilities.RestUtils;

import io.restassured.RestAssured;
import io.restassured.http.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
import io.restassured.specification.RequestSpecification;

public class TC005_Delet_Emp_Record2 extends Testbase {
	
	String empName = RestUtils.empName();
	String empSalary = RestUtils.empSal();
	String empAge = RestUtils.empAge();
	
	
	
	@BeforeClass
	void getAllEmpployees() throws Exception 
	{
	logger.info("*****************Started Delete  Emp Records*******************");
	
			
	     RestAssured.baseURI= "http://dummy.restapiexample.com/api/v1";
	     
	     httpRequest= RestAssured.given();
	     response=httpRequest.request(Method.GET,"/employees");
	     //first get the jsonpath object instance  from  the response interface
	     JsonPath jsonpatEvaluator = response.jsonPath();
	     
	     //capture id
	     String empID=jsonpatEvaluator.get("[0].id");
	     response=httpRequest.request(Method.DELETE,"/delete/"+empID);//pass id to delete
	     	     
	     Thread.sleep(5000);
	}
	@Test(enabled=true)
	void checkResponseBody()
	{
	   
	    String responseBody= response.getBody().asString();
	    
	    System.out.println("response body is :"+responseBody);
	    logger.info("*****************Checking the Response Body *******************");
	    AssertJUnit.assertEquals(responseBody.contains("successfully! deleted Records"),true);
	   
	    
	  
	}
	
	/*@Test(enabled=true)
	void checkResponseBody()
	{
	  logger.info("*****************Checking the Response body*******************");
	  
	  String responseBody= response.asString();
	  logger.info("Response Body==>"+responseBody);
	  Assert.assertTrue(responseBody!=null);
	}*/
	/*@Test(enabled=true)
	void checkResponseBody2()
	{
		  logger.info("*****************Checking the Response body*******************");
		  
		  String responseBody= response.getBody().asString();
		  logger.info("Response Body==>"+responseBody);
		  Assert.assertEquals(responseBody.contains(id), true);
		}*/
	@Test(enabled=true)
	void checkStatusCode()
	{
	  logger.info("*****************Checking the  status Code *******************");
	  
	  int statusCode= response.getStatusCode();//getting the status code
	  logger.info("Status code is ==>"+ statusCode);
	  AssertJUnit.assertEquals(statusCode, 200);
	}
	/*@Test(enabled=true)
	void checkResponseTime()
	{
	  logger.info("*****************Checking the  Response Time *******************");
	  
	  long responseTime= response.getTime();//getting the responseTime
	  logger.info("Response Time  is ==>"+ responseTime);
	  
	  if (responseTime>2000) 
		  logger.info("Response time greater than  2000");
	  
	  Assert.assertTrue(responseTime<2000);
	  
	} */
	  /*@Test(enabled=true)
		void checkStatusLine()
		{
		  logger.info("*****************Checking the  Status line *******************");
		  
		  String  statusLine= response.getStatusLine();
		  logger.info("Status line   is ==>"+ statusLine);
		  Assert.assertEquals(statusLine, "HTTP/1.1 200 OK");
	    }*/
	  @Test(enabled=true)
		void checkcontentType()
		{
		  logger.info("*****************Checking the  Content type *******************");
		  
		  String  contentType= response.header("content-type");
		  logger.info("ContentType is  ==>"+ contentType);
		  AssertJUnit.assertEquals(contentType, "application/json;charset=utf-8");
	    }
	  @Test(enabled=true)
		void checkServerType()
		{
		  logger.info("*****************Checking the  Server type *******************");
		  
		  String  serverType= response.header("Server");
		  logger.info("server Type is  ==>"+ serverType);
		  AssertJUnit.assertEquals(serverType, "nginx/1.16.0");
	    }

	  /*@Test(enabled=true)
		void checkContentEncoding()
		{
		  logger.info("*****************Checking Content Encoding *******************");
		  
		  String  contentEncoding= response.header("Content-Encoding");
		  logger.info("Content Encoding  is  ==>"+ contentEncoding);
		  Assert.assertEquals(contentEncoding, "gzip");
	    }*/
	  @Test(enabled=true)
		void checkContentLength()
		{
		  logger.info("*****************Checking Content Length *******************");
		  
		  String  contentLenght= response.header("Content-length");
		  logger.info("server Type is  ==>"+ contentLenght);
		  
		  if (Integer.parseInt(contentLenght)<100) 
			  logger.warn("Content length is less than 100");
			  
		  AssertJUnit.assertTrue(Integer.parseInt(contentLenght)<100);
	    }
	  @Test(enabled=true)
		void checkCookies()
		{
		  logger.info("*****************Checking Cookies *******************");
		  
		  String  cookie= response.getCookie("PHPSESSID");
	   }
	  @AfterMethod
	  
	  void tearDown()
	  {
		  logger.info("*****************Finised *******************");
	  }
}
